
package exerciciofix3;


public class Papagaio extends Ave
{
    private String palavras;

    public String getPalavras() {
        return palavras;
    }

    public void setPalavras(String palavras) {
        this.palavras = palavras;
    }
}
