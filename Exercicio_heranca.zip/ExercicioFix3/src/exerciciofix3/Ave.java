
package exerciciofix3;

public class Ave extends
{
    private double velocidade;
    
    public void voar()
    {
        
    }

    public double getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(double velocidade) {
        this.velocidade = velocidade;
    }
}
