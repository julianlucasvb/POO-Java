package exerciciofix3;

public class Vaca extends Mamifero 
{
    private boolean ordenha;

    public boolean isOrdenha() {
        return ordenha;
    }

    public void setOrdenha(boolean ordenha) {
        this.ordenha = ordenha;
    }
}
