package exerciciofix3;

public class Cachorro extends Mamifero 
{
    private String tipoLatido;

    
    public String getTipoLatido() {
        return tipoLatido;
    }

    
    public void setTipoLatido(String tipoLatido) {
        this.tipoLatido = tipoLatido;
    }
}
