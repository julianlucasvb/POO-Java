package exerciciofix3;

public class Mamifero extends Animal
{
    public void correr ()
    {
        
    }
}
