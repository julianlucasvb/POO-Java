package exercicio2;

public abstract class Exemplares 
{
    public abstract String realizarEmprestimo(int codigo);
    public abstract String realizarDevolucao(int codigo, boolean atraso);   
}
